import { useDispatch, useSelector } from "react-redux";
import { clearCart, removeItem } from "./CartSlice";
import { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { applyCupon, resetCupon } from "./CuponSlice.js";
import { QRCode } from "react-qrcode"; 
import emailjs from "@emailjs/browser";
import "react-toastify/dist/ReactToastify.css";
import "./Cart.css"; // We'll create this CSS file next

function Cart() {
    // Cupon related information
    const [input, setInput] = useState("");

    // Get the cupon information from store with safe default
    const cuponState = useSelector(globalState => globalState.cupon || {});
    const { code = '', discount = 0, applied = false, message = '' } = cuponState;

    // Getting Data from reducer
    const cartItems = useSelector(globalState => globalState.cart || []);

    // Dispatching the Actions
    const dispatch = useDispatch();

    // Calculate Total Amount
    const totalAmount = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

    // Calculating the percentage using useState
    const [discountPercentage, setDiscount] = useState(0);

    // Calculate Percentage amount
    const discountAmount = (totalAmount * discountPercentage) / 100;

    // Calculate After Discount Amount
    const amountAfterDiscount = totalAmount - discountAmount;

    // Calculate GST (18%)
    const gst = amountAfterDiscount * 0.18;

    // Calculate Final Amount
    const finalAmount = amountAfterDiscount + gst;

    // Calculate the Cupon discount amount
    const cuponDiscountAmount = applied ? (finalAmount * discount) / 100 : 0;

    // Calculate the TotalBill
    const totalBill = finalAmount - cuponDiscountAmount;

    const [checkout, setCheckOut] = useState(false);
    const [paymentMethod, setPaymentMethod] = useState("");
    const [customerEmail, setCustomerEmail] = useState("");

    // Available coupons
    const availableCoupons = [
        { code: "SAVE10", discount: 10 },
        { code: "SAVE20", discount: 20 },
        { code: "WELCOME", discount: 5 },
        { code: "FESTIVE25", discount: 25 }
    ];

    // Create listItems with proper styling
    const listItems = cartItems.map((item, index) => (
        <li key={item.id || index} className="cart-item">
            <span className="item-details">
                Name: {item.name} - Qty: {item.quantity} - Rs {item.price * item.quantity}
            </span>
            <button 
                className="remove-btn"
                onClick={() => {
                    dispatch(removeItem(item.id));
                    toast.error(`The Item ${item.name} is removed`);
                    if (cartItems.length === 1) {
                        dispatch(resetCupon());
                        setDiscount(0);
                    }
                }}
            >
                Remove
            </button>
        </li>
    ));

    const templateParam = {
        order_id: "ORD-839274",
        orders: cartItems.map(item => ({
            name: item.name,
            price: (item.price * item.quantity).toFixed(2),
            units: item.quantity
        })),
        cost: {
            shipping: 50,
            tax: gst.toFixed(2),
            total: totalBill.toFixed(2)
        },
        email: customerEmail
    };

    const handleCheckout = () => {
        emailjs.send("service_gxbarlh", "template_ofr7uyd", templateParam, "EeUKkPAfKargueIjG")
            .then(() => { alert("✅ Email sent Successfully!"); })
            .catch((error) => { alert("❌ Email Sending Failed: " + error.text); });
    };

    return (
        <div className="cart-container">
            <ToastContainer position="top-right" autoClose={5000} />

            {/* Navigation Bar */}
            <nav className="navbar">
                <span className="nav-item">Home</span>
                <span className="nav-item">Veg</span>
                <span className="nav-item">NonVeg</span>
                <span className="nav-item">Desserts</span>
                <span className="nav-item cart-badge">Cart (11)</span>
                <span className="nav-item">Profile</span>
                <span className="nav-item">First Post</span>
                <span className="nav-item">Second Post</span>
                <span className="nav-item">Third Post</span>
            </nav>

            {cartItems.length === 0 ? (
                <p className="empty-cart">The Cart is Empty</p>
            ) : (
                <div className="cart-content">
                    {/* Cart Items List */}
                    <ul className="cart-list">
                        {listItems}
                    </ul>

                    <button className="clear-cart-btn" onClick={() => { 
                        dispatch(clearCart()); 
                        dispatch(resetCupon()); 
                        setDiscount(0);
                    }}>
                        Clear Cart
                    </button>

                    <h2 className="total-amount">Total Amount: {totalAmount.toFixed(2)}</h2>

                    {/* Coupon Section */}
                    <div className="coupon-section">
                        <input
                            type="text"
                            className="coupon-input"
                            placeholder="FESTIVE25"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                        />
                        <button className="apply-coupon-btn" onClick={() => dispatch(applyCupon(input))}>
                            Apply Coupon
                        </button>
                    </div>

                    {/* Available Coupons */}
                    <div className="available-coupons">
                        {availableCoupons.map(coupon => (
                            <span key={coupon.code} className="coupon-tag">
                                {coupon.code}:{coupon.discount}
                            </span>
                        ))}
                    </div>

                    {/* Applied Coupon Message */}
                    {applied && (
                        <p className="coupon-applied">
                            Coupon applied: {code} ({discount}% off)
                        </p>
                    )}

                    {/* Discount Buttons */}
                    <div className="discount-buttons">
                        <button className="discount-btn green" onClick={() => setDiscount(10)}>
                            10% discount
                        </button>
                        <button className="discount-btn green" onClick={() => setDiscount(20)}>
                            20% discount
                        </button>
                        <button className="discount-btn green" onClick={() => setDiscount(30)}>
                            30% discount
                        </button>
                        <button className="discount-btn yellow" onClick={() => setDiscount(0)}>
                            No discount
                        </button>
                    </div>

                    {/* GST */}
                    <h4 className="gst">GST (18%): {gst.toFixed(2)}</h4>

                    {/* Final Amount */}
                    <h3 className="final-amount">Final Amount: {finalAmount.toFixed(2)}</h3>

                    {/* Checkout Buttons */}
                    <div className="checkout-buttons">
                        <button className="checkout-btn" onClick={() => setCheckOut(true)}>
                            Checkout
                        </button>
                        <button className="email-btn" onClick={handleCheckout}>
                            Checkout & Email
                        </button>
                    </div>

                    {/* Payment Method Selection */}
                    {checkout && (
                        <div className="payment-section">
                            <h3>Select the payment method</h3>
                            <div className="payment-buttons">
                                <button className="payment-btn" onClick={() => setPaymentMethod("qr")}>
                                    QR code
                                </button>
                                <button className="payment-btn" onClick={() => setPaymentMethod("number")}>
                                    Number
                                </button>
                            </div>
                        </div>
                    )}

                    {/* QR Code Display */}
                    {paymentMethod === "qr" && (
                        <div className="qr-section">
                            <h2>Scan QR Code to Pay</h2>
                            <QRCode 
                                value={`upi://pay?pa=shravani22d@oksbi&pn=Shravani&am=${totalBill.toFixed(2)}&cu=INR`}
                                size={200}
                                level="H"
                            />
                            <p className="upi-id">UPI ID: shravani22d@oksbi</p>
                        </div>
                    )}

                    {/* Payment by Number */}
                    {paymentMethod === "number" && (
                        <div className="number-section">
                            <h2>Pay by Phone Number</h2>
                            <p>Send payment to: +91 98765 43210</p>
                        </div>
                    )}

                    {/* Email Input for Order Confirmation */}
                    <div className="email-section">
                        <label className="email-label">Enter your Gmail to receive order</label>
                        <input
                            type="email"
                            className="email-input"
                            value={customerEmail}
                            onChange={(e) => setCustomerEmail(e.target.value)}
                            placeholder="name@email.com"
                        />
                    </div>
                </div>
            )}
        </div>
    );
}

export default Cart;