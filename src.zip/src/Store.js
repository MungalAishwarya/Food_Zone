// store.js
import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./CartSlice";
import cuponReducer from "./CuponSlice"; // Import the cupon reducer

const store = configureStore({
    reducer: {
        cart: cartReducer,
        cupon: cuponReducer, // Add cupon reducer to the store
    },
});

export default store;